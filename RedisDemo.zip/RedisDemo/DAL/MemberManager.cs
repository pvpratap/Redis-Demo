﻿using Entities;
using RedisCacheProvider;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class MemberManager
    {
        ICacheProvider _redisCacheManager;
        string _connectionString;
        public MemberManager()
        {
            _redisCacheManager = new RedisCacheManager();
            _connectionString = @"Data Source=localhost;Initial Catalog=MemberDB;Integrated Security=True";
        }

        public List<Member> GetMembers()
        {
            List<Member> members = _redisCacheManager.Get<List<Member>>("Members");

            if (members == null)
            {
                members = new List<Member>();
                Member member = null;
                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand("SELECT *FROM MEMBERS", connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                member = new Member();
                                member.Id = Convert.ToInt32(reader["Id"]);
                                member.Name = Convert.ToString(reader["Name"]);
                                members.Add(member);
                            }
                        }

                    }
                }
                _redisCacheManager.Set("Members", members);
                Console.WriteLine("Getting Data from Database");
            }
            else { Console.WriteLine("Getting Data from Redis"); }
            return members;
        }

        public bool DeleteMember(int id)
        {
            bool _isDeleted = true;
            try
            {
                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand("DELETE FROM MEMBERS WHERE Id=" + id, connection))
                    {
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch(Exception ex)
            {
                _isDeleted = false;
            }
            if(_isDeleted)
            {
                List<Member> members = _redisCacheManager.Get<List<Member>>("Members");
                if(members != null)
                {
                    Member member = members.FirstOrDefault(m => m.Id == id);
                    if (member != null)
                        members.Remove(member);
                    _redisCacheManager.Set("Members", members);
                }
            }
            return _isDeleted;
        }

        public bool UpdateMember(Member member)
        {
            bool _isUpdated = true;
            try
            {
                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    connection.Open();

                    using (SqlCommand command =
                                new SqlCommand
                                (
                                String.Format("UPDATE MEMBERS SET NAME='{0}' WHERE Id={1}", member.Name, member.Id),
                                connection
                                )
                           )
                    {
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                _isUpdated = false;
            }
            if (_isUpdated)
            {
                List<Member> members = _redisCacheManager.Get<List<Member>>("Members");
                if (members != null)
                {
                    Member memberToBeUpdated = members.FirstOrDefault(m => m.Id == member.Id);
                    if (memberToBeUpdated != null)
                        memberToBeUpdated.Name = member.Name;
                    _redisCacheManager.Set("Members", members);
                }
            }
            return _isUpdated;
        }
    }
}
