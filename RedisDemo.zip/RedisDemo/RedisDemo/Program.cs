﻿using DAL;
using Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RedisDemo
{
    class Program
    {
        static MemberManager memberManager = new MemberManager();
        static void Main(string[] args)
        {
            DisplayMembers();
            UpdateMember(2);
            DisplayMembers();
            DeleteMember(2);
            DisplayMembers();
        }

        static void DisplayMembers()
        {
            List<Member> members = memberManager.GetMembers();
            foreach (var m in members)
            {
                Console.WriteLine(m.Id + " " + m.Name);
            }
            Console.WriteLine("-------------------------");
        }

        static void DeleteMember(int id)
        {
            memberManager.DeleteMember(id);
            Console.WriteLine("After deleting member with Id "+ id);
        }

        static void UpdateMember(int id)
        {
            memberManager.UpdateMember(new Member { Id = id , Name ="updated" });
            Console.WriteLine("After updating member with Id " + id);
        }
    }
}
